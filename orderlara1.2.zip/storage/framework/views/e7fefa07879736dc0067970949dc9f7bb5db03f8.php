<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Customer')); ?></div>
                <div class="card-body" id="main-list">
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        loadData("<?php echo e(url('/customers/show')); ?>")
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>