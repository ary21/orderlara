<div class="alert alert-danger" <?php if(count($errors) < 1): ?> <?php echo e('style=display:none;'); ?> <?php endif; ?>>
    <ul class="alert-ul">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>

<form class="form myform" role="form" enctype="multipart/form-data" method="POST" action="<?php if(!empty($data)): ?> <?php echo e(route('customers.update', ['id'=>$data->id])); ?> <?php else: ?> <?php echo e(route('customers.store')); ?> <?php endif; ?>">
    <?php echo e(csrf_field()); ?>

    <?php if(isset($data)): ?> 
        <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>
    <div class="form-group">
        <label class="control-label" for="nama">Name</label>
        <input type="text" name="nama" id="nama" class="form-control" value="<?php if(isset($data)): ?><?php echo e($data->nama); ?><?php endif; ?>" autofocus>
    </div>
    <div class="form-group">
        <label class="control-label" for="telp">Phone</label>
        <input type="text" name="telp" id="telp" class="form-control" value="<?php if(isset($data)): ?><?php echo e($data->telp); ?><?php endif; ?>">
    </div>
    <div class="form-group">
        <label class="control-label" for="umur">Age</label>
        <input type="number" name="umur" id="umur" class="form-control" value="<?php if(isset($data)): ?><?php echo e($data->umur); ?><?php endif; ?>">
    </div>
    <div class="form-group">
        <label class="control-label" for="id_city">City</label>
        <div class="col-md-12 pl-0">
            <select id="id_city" class="form-control select2" name="id_city">
                <option value="">Choose City</option>
                <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>" <?php if(!empty($data)): ?> <?php if($data->id_city==$city->id): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>><?php echo e($city->city); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label" for="alamat">Address</label>
        <textarea name="alamat" id="alamat" class="form-control" cols="30" rows="5"><?php if(isset($data)): ?><?php echo e($data->alamat); ?><?php endif; ?></textarea>
    </div>
</form>