<link href="<?php echo e(asset('vendor/bootstrap-datepicker/css/datepicker.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('vendor/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>"></script>

<form class="form myform" role="form" enctype="multipart/form-data" method="POST" action="<?php if(!empty($data)): ?> <?php echo e(route('orders.update', ['id'=>$data->id])); ?> <?php else: ?> <?php echo e(route('orders.store')); ?> <?php endif; ?>">
<div>    
    <div class="alert alert-danger" <?php if(count($errors) < 1): ?> <?php echo e('style=display:none;'); ?> <?php endif; ?>>
        <ul class="alert-ul">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php echo e(csrf_field()); ?>

    <?php if(isset($data)): ?> 
        <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 float-left">
        <div class="form-group">
            <label class="control-label" for="code">Order Code</label>
            <input type="text" name="code" id="code" class="form-control" value="<?php if(isset($data)): ?><?php echo e($data->code); ?><?php endif; ?>" autofocus>
        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 float-left">
        <div class="form-group">
            <label class="control-label" for="date">Date</label>
            <input type="text" name="date" id="date" class="form-control datepicker" value="<?php if(!empty($data)): ?><?php echo e($data->date); ?><?php else: ?><?php echo e(date('Y-m-d')); ?><?php endif; ?>" >
        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 float-left">
        <div class="form-group">
            <label class="control-label" for="id_customer">Customer</label>
            <div class="col-md-12 pl-0">
                <select id="id_customer" class="form-control select2" name="id_customer">
                    <option value="">Choose Customer</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>" <?php if(!empty($data)): ?> <?php if($data->id_customer==$customer->id): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>><?php echo e($customer->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 float-left">
        <div class="form-group">
            <label class="control-label" for="id_city">City</label>
            <div class="col-md-12 pl-0">
                <select id="id_city" class="form-control select2" name="id_city">
                    <option value="">Choose City</option>
                    <?php $__currentLoopData = $citys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city->id); ?>" <?php if(!empty($data)): ?> <?php if($data->id_city==$city->id): ?> <?php echo e('selected'); ?> <?php endif; ?> <?php endif; ?>><?php echo e($city->city); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 float-left">
        <div class="table-responsive">
            <table class="table table-stripped">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Sub Total</th>
                        <th width="75"></th>
                    </tr>
                </thead>
                <tbody id="listOrder">
                    <?php $num = 1; ?>
                    <?php if(!empty($data)): ?>
                        <?php $items = json_decode($data->items) ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="list-<?php echo e($num); ?>">
                                <td><input type="text" name="items[<?php echo e($num); ?>][item]" id="item-<?php echo e($num); ?>" value="<?php echo e($item->item); ?>" class="form-control"></td>
                                <td><input type="number" name="items[<?php echo e($num); ?>][qty]" id="qty-<?php echo e($num); ?>" value="<?php echo e($item->qty); ?>" onkeyup="CalRow(<?php echo e($num); ?>)" min="1" class="form-control qtys"></td>
                                <td><input type="number" name="items[<?php echo e($num); ?>][price]" id="price-<?php echo e($num); ?>" value="<?php echo e($item->price); ?>" onkeyup="CalRow(<?php echo e($num); ?>)" class="form-control prices"></td>
                                <td><input type="number" id="sub-<?php echo e($num); ?>" class="form-control subs" value="<?php echo e($item->qty * $item->price); ?>" readonly></td>
                                <td align="center" class="pl-1 pr-1">
                                    <?php if($num!=1): ?>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="DeleteList(<?php echo e($num); ?>)" title="Delete"><i class="fa fa-trash"></i></button>&nbsp;
                                    <?php endif; ?>
                                    <button type="button" class="btn btn-sm btn-primary" onclick="AddList()" title="Add New List"><i class="fa fa-plus"></i></button>
                                </td>
                            </tr>
                            <?php $num++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr id="list-1">
                            <td><input type="text" name="items[1][item]" id="item-1" class="form-control"></td>
                            <td><input type="number" name="items[1][qty]" id="qty-1" onkeyup="CalRow(1)" min="1" value="1" class="form-control qtys"></td>
                            <td><input type="number" name="items[1][price]" id="price-1" onkeyup="CalRow(1)" class="form-control prices"></td>
                            <td><input type="number" id="sub-1" class="form-control subs" readonly></td>
                            <td align="center" class="pl-1 pr-1">
                                <button type="button" class="btn btn-sm btn-primary" onclick="AddList()" title="Add New List"><i class="fa fa-plus"></i></button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td><b>Grand Total</b></td>
                        <td><input type="text" name="totalqty" id="totalQty" class="form-control" value="<?php if(isset($data)): ?><?php echo e($data->totalqty); ?><?php endif; ?>" readonly></td>
                        <td></td>
                        <td><input type="text" name="totalgrand" id="totalGrand" class="form-control" value="<?php if(isset($data)): ?><?php echo e($data->totalgrand); ?><?php endif; ?>" readonly></td>
                        <td></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btnCloseModal btn btn-default" data-dismiss="modal">Close</button>
    <button type="submit" class="btnSaveModal btn btn-primary">Submit</button>
</div>
</form>
<script>
    var num = <?php echo e($num); ?>;

    $('.datepicker').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd'
    });

    $('#id_customer').change(function() {
        $.get(encodeURI("<?php echo e(url('/orders/getcustomer')); ?>/"+$(this).val())).done(function(res) { 
            $('#id_city').val(res.id_city);
        });
    });

    function AddList() {
        num++;
        var newlist = '<tr id="list-'+num+'">'+
            '<td><input type="text" name="items['+num+'][item]" id="item-'+num+'" class="form-control"></td>'+
            '<td><input type="number" name="items['+num+'][qty]" id="qty-'+num+'" onkeyup="CalRow('+num+')" min="1" value="1" class="form-control qtys"></td>'+
            '<td><input type="number" name="items['+num+'][price]" id="price-'+num+'" onkeyup="CalRow('+num+')" class="form-control prices"></td>'+
            '<td><input type="number" id="sub-'+num+'" class="form-control subs" readonly></td>'+
            '<td align="center" class="pl-1 pr-1">'+
                '<button type="button" class="btn btn-sm btn-danger" onclick="DeleteList('+num+')" title="Delete"><i class="fa fa-trash"></i></button>&nbsp;'+
                '<button type="button" class="btn btn-sm btn-primary" onclick="AddList()" title="Add New List"><i class="fa fa-plus"></i></button>'+
            '</td>'+
            '</tr>';

        $('#listOrder').append(newlist);
    };

    function DeleteList(lnum) {
        $('#list-'+lnum).remove();

        SumList();
    };

    function CalRow(lnum) {
        var qty = eval($('#qty-'+lnum).val());
        var price = eval($('#price-'+lnum).val());

        if (qty == undefined) qty = 0;
        if (price == undefined) price = 0;

        var sub = qty * price;

        $('#sub-'+lnum).val(sub);

        SumList();
    };

    function SumList() {
        var sumQtys = 0;
        $('.qtys').each(function(){
            var Qtys = parseFloat(this.value);
            if (Qtys == undefined) Qtys = 0;
            if (Qtys == NaN) Qtys = 0;
            
            console.log(Qtys);
            sumQtys += Qtys;
        });

        $('#totalQty').val(sumQtys);

        var sumSubs = 0;
        $('.subs').each(function(){
            var Subs = parseFloat(this.value);
            if (Subs == undefined) Subs = 0;
            
            sumSubs += Subs;
        });

        $('#totalGrand').val(sumSubs);
    };
</script>