<?php

namespace OrderLara;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    protected $table = 'citys';
}
