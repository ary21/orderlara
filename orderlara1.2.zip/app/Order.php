<?php

namespace OrderLara;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    //
}
