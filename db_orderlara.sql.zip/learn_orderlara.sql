-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 14, 2019 at 01:16 PM
-- Server version: 5.7.25-0ubuntu0.18.04.2
-- PHP Version: 7.2.16-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `learn_orderlara`
--

-- --------------------------------------------------------

--
-- Table structure for table `citys`
--

DROP TABLE IF EXISTS `citys`;
CREATE TABLE `citys` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `citys`
--

TRUNCATE TABLE `citys`;
--
-- Dumping data for table `citys`
--

INSERT INTO `citys` (`id`, `city`, `created_at`, `updated_at`) VALUES
(1, 'Parepare', '2019-04-13 07:21:00', NULL),
(2, 'Banjarbaru', '2019-04-13 07:21:00', NULL),
(3, 'Pontianak', '2019-04-13 07:21:00', NULL),
(4, 'Bau-Bau', '2019-04-13 07:21:00', NULL),
(5, 'Pematangsiantar', '2019-04-13 07:21:00', NULL),
(6, 'Administrasi Jakarta Utara', '2019-04-13 07:21:00', NULL),
(7, 'Pangkal Pinang', '2019-04-13 07:21:00', NULL),
(8, 'Banjarmasin', '2019-04-13 07:21:00', NULL),
(9, 'Bengkulu', '2019-04-13 07:21:00', NULL),
(10, 'Denpasar', '2019-04-13 07:21:00', NULL),
(11, 'Tarakan', '2019-04-13 07:21:00', NULL),
(12, 'Tangerang', '2019-04-13 07:21:00', NULL),
(13, 'Tanjungbalai', '2019-04-13 07:21:00', NULL),
(14, 'Balikpapan', '2019-04-13 07:21:01', NULL),
(15, 'Subulussalam', '2019-04-13 07:21:01', NULL),
(16, 'Banjar', '2019-04-13 07:21:01', NULL),
(17, 'Ternate', '2019-04-13 07:21:01', NULL),
(18, 'Cirebon', '2019-04-13 07:21:01', NULL),
(19, 'Palopo', '2019-04-13 07:21:01', NULL),
(20, 'Bima', '2019-04-13 07:21:01', NULL),
(21, 'Ternate', '2019-04-13 07:21:01', NULL),
(22, 'Palangka Raya', '2019-04-13 07:21:01', NULL),
(23, 'Sabang', '2019-04-13 07:21:01', NULL),
(24, 'Mataram', '2019-04-13 07:21:01', NULL),
(25, 'Subulussalam', '2019-04-13 07:21:01', NULL),
(26, 'Banjar', '2019-04-13 07:21:01', NULL),
(27, 'Pontianak', '2019-04-13 07:21:01', NULL),
(28, 'Jambi', '2019-04-13 07:21:01', NULL),
(29, 'Tidore Kepulauan', '2019-04-13 07:21:01', NULL),
(30, 'Bima', '2019-04-13 07:21:01', NULL),
(31, 'Gunungsitoli', '2019-04-13 07:21:01', NULL),
(32, 'Subulussalam', '2019-04-13 07:21:02', NULL),
(33, 'Sukabumi', '2019-04-13 07:21:02', NULL),
(34, 'Cilegon', '2019-04-13 07:21:02', NULL),
(35, 'Gunungsitoli', '2019-04-13 07:21:02', NULL),
(36, 'Bau-Bau', '2019-04-13 07:21:02', NULL),
(37, 'Tegal', '2019-04-13 07:21:02', NULL),
(38, 'Surabaya', '2019-04-13 07:21:02', NULL),
(39, 'Solok', '2019-04-13 07:21:02', NULL),
(40, 'Probolinggo', '2019-04-13 07:21:02', NULL),
(41, 'Palangka Raya', '2019-04-13 07:21:02', NULL),
(42, 'Gorontalo', '2019-04-13 07:21:02', NULL),
(43, 'Administrasi Jakarta Timur', '2019-04-13 07:21:02', NULL),
(44, 'Tanjungbalai', '2019-04-13 07:21:02', NULL),
(45, 'Sungai Penuh', '2019-04-13 07:21:02', NULL),
(46, 'Langsa', '2019-04-13 07:21:02', NULL),
(47, 'Solok', '2019-04-13 07:21:02', NULL),
(48, 'Palembang', '2019-04-13 07:21:02', NULL),
(49, 'Padangsidempuan', '2019-04-13 07:21:02', NULL),
(50, 'Pekalongan', '2019-04-13 07:21:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telp` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `umur` tinyint(4) NOT NULL,
  `id_city` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `customers`
--

TRUNCATE TABLE `customers`;
--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `nama`, `telp`, `alamat`, `umur`, `id_city`, `created_at`, `updated_at`) VALUES
(1, 'Adika Firgantoro', '0471 1143 2427', 'Ds. Perintis Kemerdekaan No. 702, Mataram 67664, Banten', 38, 13, '2019-04-13 07:20:59', NULL),
(2, 'Hamima Astuti M.M.', '(+62) 358 0715 902', 'Dk. Adisumarmo No. 57, Singkawang 40111, SumSel', 27, 8, '2019-04-13 07:20:59', NULL),
(3, 'Nilam Susanti', '(+62) 242 9619 669', 'Kpg. Baing No. 160, Tangerang 83353, Lampung', 32, 33, '2019-04-13 07:20:59', NULL),
(4, 'Raina Kuswandari', '(+62) 435 7293 8408', 'Kpg. Ujung No. 676, Jayapura 72773, Riau', 33, 37, '2019-04-13 07:20:59', NULL),
(6, 'Rama Hidayanto S.Sos', '(+62) 882 3738 704', 'Psr. S. Parman No. 336, Ternate 49087, JaBar', 27, 32, '2019-04-13 07:20:59', NULL),
(7, 'Padmi Wijayanti S.Psi', '(+62) 347 0116 8660', 'Jln. Gading No. 608, Cimahi 89549, SulUt', 27, 7, '2019-04-13 07:20:59', NULL),
(8, 'Belinda Wahyuni S.Farm', '(+62) 222 9703 5069', 'Ds. Dago No. 358, Tangerang Selatan 26492, NTB', 29, 12, '2019-04-13 07:20:59', NULL),
(9, 'Zizi Wijayanti', '0964 0534 892', 'Gg. Hang No. 145, Mojokerto 69124, SulUt', 35, 30, '2019-04-13 07:20:59', NULL),
(10, 'Ajeng Ratna Hasanah', '(+62) 29 7470 038', 'Ds. Nangka No. 462, Tomohon 94824, KalUt', 27, 2, '2019-04-13 07:20:59', NULL),
(11, 'Gandi Sihombing', '(+62) 221 8082 957', 'Gg. Batako No. 365, Administrasi Jakarta Barat 74791, PapBar', 36, 38, '2019-04-13 07:20:59', NULL),
(12, 'Hairyanto Budiman', '(+62) 796 1295 193', 'Dk. Cihampelas No. 993, Gorontalo 83664, SumBar', 28, 30, '2019-04-13 07:21:00', NULL),
(13, 'Elon Jefri Hidayat', '028 8785 2076', 'Ki. Camar No. 583, Pangkal Pinang 33595, Bengkulu', 40, 33, '2019-04-13 07:21:00', NULL),
(14, 'Nasab Mursita Siregar S.T.', '0921 1611 0048', 'Ds. Baranangsiang No. 987, Yogyakarta 46887, Bengkulu', 25, 23, '2019-04-13 07:21:00', NULL),
(15, 'Galih Anggriawan', '(+62) 997 0075 779', 'Kpg. Setiabudhi No. 221, Metro 64110, Gorontalo', 34, 4, '2019-04-13 07:21:00', NULL),
(16, 'Mala Hariyah', '0656 2655 3785', 'Gg. Wora Wari No. 228, Palembang 82976, DIY', 29, 32, '2019-04-13 07:21:00', NULL),
(17, 'Ana Fitriani Yuliarti M.Farm', '(+62) 543 3211 4651', 'Gg. Ujung No. 897, Pariaman 20328, Riau', 29, 4, '2019-04-13 07:21:00', NULL),
(19, 'Ana Melani', '0458 8944 4851', 'Dk. Flores No. 97, Cilegon 84056, Bengkulu', 26, 18, '2019-04-13 07:21:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `migrations`
--

TRUNCATE TABLE `migrations`;
--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_04_06_140505_create_customers_table', 1),
(4, '2019_04_06_143206_create_citys_table', 1),
(5, '2019_04_07_233945_create_orders_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_city` int(11) NOT NULL,
  `totalqty` int(11) NOT NULL,
  `totalgrand` int(11) NOT NULL,
  `items` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `orders`
--

TRUNCATE TABLE `orders`;
--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `code`, `date`, `id_customer`, `id_city`, `totalqty`, `totalgrand`, `items`, `created_at`, `updated_at`) VALUES
(1, 'A123', '2019-04-13', 1, 13, 23, 34000, '{\"1\":{\"item\":\"Kopi\",\"qty\":\"12\",\"price\":\"1000\"},\"2\":{\"item\":\"Susu\",\"qty\":\"11\",\"price\":\"2000\"}}', '2019-04-13 07:27:20', '2019-04-13 23:14:49'),
(4, 'B123', '2019-04-13', 4, 37, 13, 34100, '{\"1\":{\"item\":\"Susu\",\"qty\":\"3\",\"price\":\"1200\"},\"2\":{\"item\":\"Kopi\",\"qty\":\"5\",\"price\":\"2500\"},\"3\":{\"item\":\"Gula\",\"qty\":\"5\",\"price\":\"3600\"}}', '2019-04-13 07:28:09', '2019-04-13 23:12:58'),
(5, 'C123', '2019-05-03', 2, 8, 5, 14500, '{\"1\":{\"item\":\"Gula\",\"qty\":\"2\",\"price\":\"2000\"},\"2\":{\"item\":\"Kopi\",\"qty\":\"3\",\"price\":\"3500\"}}', '2019-04-13 23:10:30', '2019-04-13 23:11:12');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `password_resets`
--

TRUNCATE TABLE `password_resets`;
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Truncate table before insert `users`
--

TRUNCATE TABLE `users`;
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@email.com', NULL, '$2y$10$zewhnG9341RVi.RZDmeEM.d/BkpuyeJPDCr.pkIEpWo.SyIvAEbMK', NULL, '2019-04-13 07:20:28', '2019-04-13 07:20:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `citys`
--
ALTER TABLE `citys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `citys`
--
ALTER TABLE `citys`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
